package Servlets;

/**
* Class: CIST 2931 Advanced Systems Project
* Semester: Fall 2020
* Instructor: Ronald Enz
* Description: LoginServlet.java
* Due: 09.10.2020
* @authors Ian Mashburn
* @version 1.0
*
* By turning in this code, I Pledge:
* 1. That I have completed the programming assignment independently.
* 2. I have not copied the code from a student or any source.
* 3. I have not given my code to any student.
 */

import BusinessObjects.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        System.out.println("*************************** IN LoginServlet *******************"); 
  
        String idFromForm = "", passFromForm = "";
        boolean grantAccess = false;
        boolean invalidlogin = false;
        
        System.out.println("*************** REQUEST FROM LOGIN FORM *********");
        idFromForm = request.getParameter("user");
        passFromForm = request.getParameter("pass");
        System.out.println("user: " + idFromForm);
        System.out.println("pass: " + passFromForm);        
        System.out.println("*************** REQUESTED FROM LOGIN FORM *******");
        
        HttpSession session = request.getSession();
                   
        try {                                       
            Customer custObject = new Customer();   // create Customer Object
                                                    // do not allow Guest logins
            if (idFromForm.equalsIgnoreCase("guest")){
                grantAccess = false;
            } else {
                invalidlogin = false;
                                                    // check DB for loginID
                custObject.loginDB(idFromForm,passFromForm);

                if (custObject.custNotFound){
                    System.out.println("Caught a bad login");
                    custObject.custNotFound = false;// reset flag custNotFound
                    grantAccess = false;            // set grantAccess flag
                } else {                            // grantAccess
                                                    // verify against Object Data
                    grantAccess = (idFromForm.equals(custObject.getCustLoginID()) && (passFromForm.equals(custObject.getCustPassword())));
                }
            }
                
            // put Customer Object into session and forward to custindex.jsp
            if (grantAccess){
                System.out.println("Access Granted");
                session.setAttribute("custObject", custObject); 
                System.out.println("------------------------------------------------------------------------");
                System.out.println("LoginServlet:Customer custObject ADDED to session");
                custObject.show();
                System.out.println("------------------------------------------------------------------------");
                                                // send to custindex.jsp
                response.sendRedirect("http://localhost:8080/TeamOneSports/custindex.jsp");
            } else {                            // ELSE send back to index.jsp
                System.out.println("Access NOT Granted");
                invalidlogin = true;
                session.setAttribute("invalidlogin",invalidlogin);
                response.sendRedirect("http://localhost:8080/TeamOneSports/index.jsp");
            }
        }
        catch(IOException e){
            System.out.println("PP: " + e);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
